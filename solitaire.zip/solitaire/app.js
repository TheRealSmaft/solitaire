const express = require("express");
const http = require("http");
const path = require("path");
const SolitaireRouter = require("./scripts/solitaire/solitaire-router");

var app = express();
app.use(express.static(__dirname));

app.set("views", path.resolve(__dirname, "views"));
app.set("view engine", "ejs");

app.get("/", function(req, res) {
    res.render("index", {
        title: "World Championship Solitaire"
    });
});

let sr = new SolitaireRouter(app);

http.createServer(app).listen(8080, function() {
    console.log("Application started on port 8080!");
});