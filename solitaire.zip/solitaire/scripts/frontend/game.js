function getCard(request) {
    let http = new XMLHttpRequest();
    let url = window.location.href + request.url + "/" + JSON.stringify(request.params);
    http.open("GET", url);
    http.send();
    http.onreadystatechange = function() {
        if(this.readyState == 4 && this.status == 200) {
            console.log(JSON.parse(http.responseText));
        }
    }
}

function initializeGame() {
    let stackPromise = mainStackActions(0, {type: "GET_ALL_STACKS"});
    stackPromise.then(function(stacks) {
        setupStacks(stacks);
    });

    let deckPromise = dealerActions({type: "GET_DECK"});
    deckPromise.then(function(deck) {
        setupDeck(deck);
    });
}

async function getGame() {
    let response = await fetch("game");

    if(response.status == 200) {
        let json = await response.json();
        return json;
    }

    throw new Error(response.status);
}

async function dealerActions(action) {
    let res = await fetch("dealer/" + JSON.stringify(action));

    if(res.status == 200) {
        let json = await res.json();
        return json;
    }

    throw new Error(res.status);
}

async function mainStackActions(stackIndex, action) {
    let res = await fetch("mainStack/" + stackIndex + "/action/" + JSON.stringify(action));

    if(res.status == 200) {
        let json = await res.json();
        return json;
    }

    throw new Error(res.status);
}

function setupStacks(stacks) {
    let mainStackContainer = new PIXI.Container();
    PixiApp.app.stage.addChild(mainStackContainer);

    for(let i = 0; i < stacks.length; i++) {
        let stack = stacks[i];
        let pixiStack = new PixiStack(mainStackContainer, { offset: [i * 30, 0] });
        for(let j = stack.cards.length - 1; j > -1; j--) {
            let pixiCard = new PixiCard(stack.cards[j]);
            pixiStack.addCard(pixiCard);
        }
    }

    PixiApp.model.broadcast();

    mainStackContainer.x = (PixiApp.app.screen.width - mainStackContainer.width) / 2;
    mainStackContainer.y = (PixiApp.app.screen.height - mainStackContainer.height) / 2;

    let sortedStackContainer = new PIXI.Container();
    PixiApp.app.stage.addChild(sortedStackContainer);

    for(let i = 0; i < 4; i++) {
        let stack = new PixiStack(sortedStackContainer, { offset: [i * 30, 0] });
    }

    sortedStackContainer.x = (PixiApp.app.screen.width - sortedStackContainer.width) / 2;
    sortedStackContainer.y = 40;
}

function setupDeck(deck) {
    let pixiStack = new PixiStack(PixiApp.app.stage, { increment: [0, -.7], offset: [10, 20] })

    for(let i = deck.length - 1; i > -1; i--) {
        let card = new PixiCard(deck[i]);
        pixiStack.addCard(card);
    }

    PixiApp.model.broadcast();
}