function init() {
    // gameRequest({url: "card", params: { stack: 1 }});
    initializeGame();
}

// Run init() on load
document.addEventListener("DOMContentLoaded", function() {
    init();
});

