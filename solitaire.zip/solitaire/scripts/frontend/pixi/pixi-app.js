var PixiApp = (function() {
    let instance;

    function createInstance() {
        let node = document.getElementById("game");
        let app = new PIXI.Application({antialias: true, backgroundColor: 0x1099bb});
        node.appendChild(app.view);

        let pixiModel = new PixiModel();
        let pixiController = new PixiController(pixiModel);

        

        function scaleApp() {
            let appSize = document.getElementById("game").getBoundingClientRect().width;
            app.renderer.resize(appSize, appSize * (5 / 5.5));
            app.stage.scale.set(appSize / 600);
        }

        scaleApp();
        window.addEventListener("resize", scaleApp);

        return {
            app: app,
            model: pixiModel,
            controller: pixiController
        };
    }

    function getInstance() {
        if(!instance) {
            instance = createInstance();
        }
        return instance;
    }

    return getInstance();
})();