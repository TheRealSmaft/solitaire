function PixiCard(cardData) {
    let fill;
    let card = new PIXI.Container();
    card.suit = cardData.suit;
    card.rank = cardData.rank;
    card.faceUp = cardData.faceUp || false;
    card.flippable = cardData.flippable || false;

    let cardFace = new PIXI.Graphics();
    cardFace.lineStyle(.5, 0x222222, 1);
    cardFace.beginFill(0xFFFFFF, 1);
    cardFace.drawRoundedRect(0, 0, 50, 70, 5);
    cardFace.endFill();

    let cardBack = new PIXI.Graphics();
    cardBack.lineStyle(.5, 0x222222, 1);
    cardBack.beginFill(0x888888, 1);
    cardBack.drawRoundedRect(0, 0, 50, 70, 5);
    cardBack.endFill();

    generateCard();
    generateSuit(cardData.suit);
    generateRank(cardData.rank);
    card.pivot.x = card.width / 2;
    card.pivot.y = card.height / 2;

    function generateCard() {
        if(card.faceUp) {
            card.addChild(cardFace);
            cardFace.position.x = (card.width - cardFace.width) / 2;
            cardFace.position.x = (card.height - cardFace.height) / 2;
        }
        else {
            card.addChild(cardBack);
            cardBack.position.x = (card.width - cardBack.width) / 2;
            cardBack.position.x = (card.height - cardBack.height) / 2;
        }
    }

    function generateSuit(suit) {
        let suitText = new PIXI.Text(getSymbol(suit), {
            fontFamily: "Arial", 
            fontSize: 28, 
            fill: fill
        });

        cardFace.addChild(suitText);
        suitText.x = (card.width - suitText.width) / 2;
        suitText.y = (card.height - suitText.height) / 2;

        function getSymbol() {
            let symbol;
            switch(suit) {
                case "hearts": {
                    fill = 0xFF0000;
                    symbol = "♥";
                    break;
                }
                case "clubs": {
                    fill = 0x000000;
                    symbol = "♣";
                    break;
                }
                case "diamonds": {
                    fill = 0xFF0000;
                    symbol = "♦";
                    break;
                }
                case "spades": {
                    fill = 0x000000;
                    symbol = "♠";
                    break;
                }
            }
            return symbol;
        }
    }

    function generateRank(rank) {
        let rankAbbrev = rank === "10" ? rank : rank[0].toUpperCase();
        let style = {
            fontFamily: "Arial",
            fontSize: 18,
            fill: fill,
            align: "center"
        };

        let rankText1 = new PIXI.Text(rankAbbrev, style);

        cardFace.addChild(rankText1);
        rankText1.x = 3;
        rankText1.y = 2;

        let rankText2 = new PIXI.Text(rankAbbrev, style);

        cardFace.addChild(rankText2);
        rankText2.x = card.width - rankText2.width + 3;
        rankText2.y = card.height - rankText2.height + 7;
        rankText2.anchor.set(0.5);
        rankText2.rotation = 3.14159;
    }

    card.flipCard = function() {
        let add = card.faceUp ? cardBack : cardFace;
        let remove = card.faceUp ? cardFace : cardBack;
        card.removeChild(remove);
        card.addChild(add);
        card.faceUp = true;
        card.flippable = false;
    }

    card.onDragStart = function(e) {
        this.data = e.data;
        this.originalX = card.x;
        this.originalY = card.y;
        this.dragging = true;
    }

    card.attachToCard = function(e, otherCard, increment) {
        this.data = e.data;
        this.originalParent = this.parent;
        this.otherCard = otherCard;
        this.originalX = card.x;
        this.originalY = card.y;
        this.originalParent.removeChild(card);
        this.otherCard.addChild(card);

        card.x = card.width / 2;
        card.y = card.height / 2 + increment;
    }

    // DETACH DRAG AND DROP SO IT CAN BE USED WITH ANY PIXI.JS ENTITY
    // Have an invisible drag container that takes an array of cards as children
    // DraggableContainer as singleton. Has drag methods
    // Recognizes what other cards are being hover over... 
    // Hover method on cards that puts a card in the PixiModel hoverCard when selectedCards is not empty
    // Defers to GameActionAuditor
    // GameActionAuditor looks at the top selectedCard and compares it with hoverCard
    // if it is a legal move, and the player onDragStops, execute server actions

    card.detachFromCard = function() {
        
        this.data = null;
    }

    function onDragMove() {
        if(this.dragging) {
            let newPos = this.data.getLocalPosition(this.parent);
            this.x = newPos.x;
            this.y = newPos.y;
        }
    }

    function onDragEnd() {
        console.log(this.data)
        this.dragging = false;
        card.x = this.originalX;
        card.y = this.originalY;
        this.data = null;
        PixiApp.model.selectedCards = [];
    }

    card.interactive = true;
    card
        .on("pointerdown", (e) => onClick(e))
        .on("pointermove", onDragMove)
        .on("pointerup", onDragEnd)
        .on("pointerupoutside", onDragEnd);

    function onClick(e) {
        card.parent.onCardClick(e, card);
    }

    let observer = new PixiObserver(this, PixiApp.controller);

    this.update = function(data) {
        for (const key in data) {
            if (self.hasOwnProperty(key)) {
                self[key] = data[key];
            }
        }
    }
    
    return card;
}
