function PixiModel() {
    let self = this;
    this.observers = [];

    this.subscribe = function(observer) {
        self.observers.push(observer);
    }

    this.unsubscribe = function(observer) {
        self.observers = self.observers.filter(subscriber => subscriber !== observer);
    }

    this.broadcast = function() {
        for(let o of self.observers) {
            o.update({
                selectedCards: selectedCards
            });
        }
    }

    let selectedCards = [];

    Object.defineProperty(this, "selectedCards", {
        get: function() { return selectedCards; },
        set: function(value) {
            selectedCards = value;
            this.broadcast();
        }
    });

    // let appSize;
    // let heightRatio = [5, 5.5];

    // Object.defineProperty(this, "appSize", {
    //     get: function() { return appSize; },
    //     set: function(value) {
    //         appSize = value;
    //         this.broadcast();
    //     }
    // });

    // Object.defineProperty(this, "heightRatio", {
    //     get: function() { return heightRatio; },
    //     set: function(value) {
    //         heightRatio = value;
    //         this.broadcast();
    //     }
    // });

}

function PixiObserver(observer, controller) {
    this.controller = controller;
    this.update = function(data) {
       observer.update(data);
    }
    this.controller.model.subscribe(this);
}

function PixiController(model) {
    let self = this;
    this.model = model;

    // this.cardEvent = function(e, card) {
    //     e.stopPropagation();
    //     if(card.faceUp) {
    //         switch(e.type) {
    //             case "pointermove": {
    //                 card.onDragMove();
    //                 break;
    //             }
    //             case "pointerdown": {
    //                 card.onDragStart(e);
    //                 break;
    //             }
    //             case "pointerup": 
    //             case "pointerupoutside": {
    //                 card.onDragEnd();
    //                 break;
    //             }
    //         }
    //     }
    //     else {
    //         if(card.flippable) {
    //             card.flipCard();
    //         }
    //     }
    // }
}
