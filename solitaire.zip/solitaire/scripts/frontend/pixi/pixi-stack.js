function PixiStack(parent, options) {
    parent = parent || PixiApp.getInstance().stage;
    let offset = options.offset || [0, 0];
    let increment = options.increment || [0, 30];
    let faceUp = options.faceUp || false;
    let length = 0;

    let stack = new PIXI.Container();
    parent.addChild(stack);
    stack.x = stack.parent.x + offset[0];
    stack.y = stack.parent.y + offset[1];
    let faceUpCards = [];
    let faceDownCards = [];

    function addCard(card) {
        stack.addChild(card);
        card.x = stack.x + (length * increment[0]) + (card.width / 2);
        card.y = stack.y + (length * increment[1]) + (card.height / 2);
        length++;

        if(!card.faceUp) {
            card.flipCard()
        }

        if(card.faceUp) {
            faceUpCards.unshift(card);
        }
        else {
            faceDownCards.unshift(card);
        }
    }

    stack.onCardClick = function(event, card) {
        if(card.faceUp) {
            card.onDragStart(event);
            let index = faceUpCards.indexOf(card);
            
            if(index > 0) {
                PixiApp.model.selectedCards = faceUpCards.slice(0, index + 1)
            }
            else {
                PixiApp.model.selectedCards = [card];
            }

            for(let i = PixiApp.model.selectedCards.length - 2; i > -1; i--) {
                // let inc = ((PixiApp.model.selectedCards.length - i - 1) * increment[1]);
                // PixiApp.model.selectedCards[i].attachToCard(event, card, inc);
                PixiApp.model.selectedCards[i].onDragStart(event);
            }
        }
        else {
            if(card.flippable) {
                card.flipCard();
            }
        }
    }

    let observer = new PixiObserver(this, PixiApp.controller);

    this.appSize = "";
    this.heightRatio = "";

    let self = this;

    this.update = function(data) {
        for (const key in data) {
            if (self.hasOwnProperty(key)) {
                self[key] = data[key];
            }
        }
    }

    return {
        stack: stack,
        addCard: addCard,
    }
}