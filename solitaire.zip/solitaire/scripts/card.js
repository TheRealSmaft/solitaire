function Card(suit, rank) {
    this.suit = suit;
    this.rank = rank;
    this.faceUp = false;
}

module.exports = Card;