var CardFactory = require("./card-factory");

var Dealer = (function() {
    let dealer;

    function createDealer() {
        let deck = CardFactory.getCards();
        return {
            shuffle: function(cards) {
                let shouldReturn = cards ? true : false;
                cards = cards || deck;
                var currentIndex = cards.length, temporaryValue, randomIndex;
                while (0 !== currentIndex) {

                    randomIndex = Math.floor(Math.random() * currentIndex);
                    currentIndex -= 1;

                    temporaryValue = cards[currentIndex];
                    cards[currentIndex] = cards[randomIndex];
                    cards[randomIndex] = temporaryValue;
                }
                return shouldReturn ? cards : null;
            },
            deal: function(count) {
                let cards = [];
                for(let i = 0 ; i < count; i++) {
                    cards.push(deck.shift());
                }
                return cards;
            },
            takeCard: function() {
                return deck.shift();
            },
            takeRandomCard: function() {
                return deck.splice(Math.floor(Math.random * cards.length - 1), 1);
            },
            getCardCount: function() {
                return deck.length;
            },
            getDeck: function() {
                return deck;
            }
        }
    }

    function getDealer() {
        if(!dealer) {
            dealer = createDealer();
        }
        return dealer;
    }

    return getDealer();
})();

Dealer.shuffle();

module.exports = Dealer;