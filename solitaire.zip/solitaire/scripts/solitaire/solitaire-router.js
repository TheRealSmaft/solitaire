const Solitaire = require("./solitaire");

function SolitaireRouter(app) {
    app.get("/game", function(req, res) {
        let game = {
            deck: Solitaire.dealer.getDeck(),
            mainStacks: Solitaire.board.mainStacks
        }
        res.json(game);
    });

    app.get("/card/:cardData", function(req, res) {
        let cd = JSON.parse(req.params.cardData);
        let card = Solitaire.board.takeCard(cd.stack);
        res.json(card);
    });

    app.get("/dealer/:action", function(req, res) {
        let action = JSON.parse(req.params.action);
        res.json(dealerActions(action));
    });

    app.get("/mainStack/:index/action/:action", function(req, res) {
        let i = parseInt(req.params.index);
        let action = JSON.parse(req.params.action);
        if(action.type === "GET_ALL_STACKS") {
            res.json(Solitaire.board.mainStacks);
        }
        else {
            let stack = Solitaire.board.mainStacks[i];
            res.json(stackActions(stack, action));
        }
    });

    function dealerActions(action) {
        let resObj;
        switch(action.type) {
            case "SHUFFLE": {
                Solitaire.dealer.shuffle();
            }
            case "GET_DECK": {
                resObj = Solitaire.dealer.getDeck();
                break;
            }
            case "DEAL": {
                resObj = Solitaire.dealer.deal(action.payload);
                break;
            }
            case "TAKE_CARD": {
                resObj = Solitaire.dealer.takeCard();
                break;
            }
            case "TAKE_RANDOM_CARD": {
                resObj = Solitaire.dealer.takeRandomCard();
                break;
            }
            default: {
                console.error(action.type + " is not a valid Dealer action!");
                break;
            }
        }
        return resObj;
    }

    function stackActions(stack, action) {
        let resObj;
        switch(action.type) {
            case "GET_STACK": {
                resObj = stack;
                break;
            }
            case "ADD_CARD": {
                stack.addCard(action.payload);
                resObj = stack;
                break;
            }
            case "ADD_CARDS": {
                stack.addCards(action.payload);
                resObj = stack;
                break;
            }
            case "TAKE_TOP_CARD": {
                resObj = stack.takeTopCard();
                break;
            }
            case "TAKE_RANDOM_CARD": {
                resObj = stack.takeRandomCard();
                break;
            }
            case "TAKE_ALL_CARDS": {
                resObj = stack.takeAllCards();
                break;
            }
            default: {
                console.error(action.type + " is not a valid CardStack action!");
                break;
            }
        }
        return resObj;
    }
}

module.exports = SolitaireRouter;