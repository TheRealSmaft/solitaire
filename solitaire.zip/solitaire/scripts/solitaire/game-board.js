var dealer = require("../dealer");
var CardStack = require("../card-stack");

function GameBoard() {
    let mainStacks = [];
    let sortedStacks = [];

    for(let i = 0; i < 7; i++) {
        let stack = new CardStack(dealer.deal(i + 1));
        stack.cards[0].faceUp = true;
        mainStacks.push(stack);
    }

    for(let i = 0; i < 4; i++) {
        let stack = new CardStack();
        sortedStacks.push(stack);
    }

    function takeCard(stackIndex, fromSorted) {
        fromSorted = fromSorted || false;
        return fromSorted ? sortedStacks[stackIndex].takeTopCard() : mainStacks[stackIndex].takeTopCard();
    }

    function addCard(card, stackIndex, toSorted) {
        toSorted = toSorted || false;
        if(toSorted) {
            sortedStacks[stackIndex].addCard(card);
        }
        else {
            mainStacks[stackIndex].addCard(card);
        }
    }

    return {
        takeCard: takeCard,
        addCard: addCard,
        mainStacks: mainStacks,
        sortedStacks: sortedStacks
    }
}

module.exports = GameBoard;