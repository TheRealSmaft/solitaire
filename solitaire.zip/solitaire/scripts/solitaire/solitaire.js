var Dealer = require("../dealer");
var GameBoard = require("./game-board");

var Solitaire = (function() {
    let game;

    function createGame() {
        let gb = new GameBoard();
        return {
            board: gb,
            dealer: Dealer
        }
    }

    function getInstance() {
        if(!game) {
            game = createGame();
        }
        return game;
    }

    return getInstance();
})();

module.exports = Solitaire;