function CardStack(cardsToAdd) {
    let cards = cardsToAdd || [];

    function addCard(card) {
        cards.push(card);
    }

    function addCards(cardsToAdd) {
        cards = cards.concat(cardsToAdd);
    }

    function takeTopCard() {
        return cards.shift();
    }

    function takeRandomCard() {
        return cards.splice(Math.floor(Math.random * cards.length - 1), 1);
    }

    function takeAllCards() {
        let allCards = cards;
        cards = [];
        return allCards;
    }

    return {
        cards: cards,
        addCard: addCard,
        addCards: addCards,
        takeTopCard: takeTopCard,
        takeRandomCard: takeRandomCard,
        takeAllCards: takeAllCards
    }
}

module.exports = CardStack;