var Card = require("./card");

const CardFactory = (function() {
    let instance;

    function createInstance() {
        let cards = [];
        for(let i = 0; i < 13; i++) {
            for(let j = 0; j < 4; j++) {
                let suit;
                switch(j) {
                    case 0: {
                        suit = "hearts";
                        break;
                    }
                    case 1: {
                        suit = "clubs";
                        break;
                    }
                    case 2: {
                        suit = "diamonds";
                        break;
                    }
                    case 3: {
                        suit = "spades";
                        break;
                    }
                    default: {
                        break;
                    }
                }

                let rank = getRank(i);

                function getRank(index) {
                    if(index < 9) {
                        return (index + 2).toString();
                    }
                    let r;
                    switch(index) {
                        case 9: {
                            r = "jack"; 
                            break;
                        }
                        case 10: {
                            r = "queen"
                            break;
                        }
                        case 11: {
                            r = "king";
                            break;
                        }
                        case 12: {
                            r = "ace";
                            break;
                        }
                        default: {
                            break;
                        }
                    }
                    return r;
                }
                cards.push(new Card(suit, rank));
            }
        }
        return cards;
    }

    function getInstance() {
        if(!instance) {
            instance = createInstance();
        }
        return instance;
    }

    return {
        getCards: getInstance
    }
})();

module.exports = CardFactory;